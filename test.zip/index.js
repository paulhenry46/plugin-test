"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.tsx
var index_exports = {};
__export(index_exports, {
  NOT_PRIVILEGED_MSG: () => NOT_PRIVILEGED_MSG,
  hooks: () => hooks,
  isCapable: () => isCapable
});
module.exports = __toCommonJS(index_exports);

// src/hooks/onComposeSend.ts
async function onComposeSend(req) {
  return void 0;
}

// src/index.tsx
var NOT_PRIVILEGED_MSG = 'OpenPGP could not start: it is running in the restricted (untrusted) plugin sandbox, where in-browser cryptography and key storage are unavailable. This plugin must be delivered as a signed, admin-approved bundle with "tier": "privileged" so it loads in the same-origin tier. Contact your administrator.';
var _capable = null;
async function isCapable() {
  if (_capable !== null) return _capable;
  try {
    if (typeof indexedDB === "undefined" || !(crypto && crypto.subtle)) throw new Error("missing apis");
    await new Promise((resolve, reject) => {
      let req;
      try {
        req = indexedDB.open("pgp-capability-probe");
      } catch (e) {
        reject(e);
        return;
      }
      req.onsuccess = () => {
        try {
          req.result.close();
        } catch {
        }
        resolve(void 0);
      };
      req.onerror = () => reject(req.error || new Error("indexedDB open failed"));
      req.onblocked = () => resolve(void 0);
    });
    _capable = true;
  } catch {
    _capable = false;
  }
  return _capable;
}
var hooks = {
  onComposeSend
};
